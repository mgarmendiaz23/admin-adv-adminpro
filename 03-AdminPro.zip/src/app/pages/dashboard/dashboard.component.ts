import { Component } from '@angular/core';

@Component({
  templateUrl: './dashboard.component.html',
  styles: [    
  ],
})
export class DashboardComponent {

}
